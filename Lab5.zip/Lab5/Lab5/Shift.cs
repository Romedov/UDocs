﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Lab5
{
    class Shift : INotifyPropertyChanged
    {
        #region Event handlers
        public event PropertyChangedEventHandler PropertyChanged;
        #endregion
        #region Private fields
        private int _id;
        private DateTime _startDate;
        private DateTime _endDate;
        private decimal _cash;
        private decimal _sellings;
        private decimal _returns;
        private decimal _put;
        private decimal _withdrawn;
        #endregion
        #region Public properties
        public int Id
        {
            get { return _id; }
            set { _id = value; OnPropertyChanged(); }
        }
        public DateTime StartDate
        {
            get { return _startDate; }
            set { _startDate = value; OnPropertyChanged(); }
        }
        public DateTime EndDate
        {
            get { return _endDate; }
            set { _endDate = value; OnPropertyChanged(); }
        }
        public decimal Cash
        {
            get { return _cash; }
            set { _cash = value; OnPropertyChanged(); }
        }
        public decimal Sellings
        {
            get { return _sellings; }
            set { _sellings = value; OnPropertyChanged(); }
        }
        public decimal Returns
        {
            get { return _returns; }
            set { _returns = value; OnPropertyChanged(); }
        }
        public decimal Put
        {
            get { return _put; }
            set { _put = value; OnPropertyChanged(); }
        }
        public decimal Withdrawn
        {
            get { return _withdrawn; }
            set { _withdrawn = value; OnPropertyChanged(); }
        }
        #endregion
        #region Methods
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
        #endregion
    }
}
