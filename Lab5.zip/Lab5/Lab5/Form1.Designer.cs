﻿namespace Lab5
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.ShiftGridView = new System.Windows.Forms.DataGridView();
            this.CmdButton = new System.Windows.Forms.Button();
            this.QueryTypeComboBox = new System.Windows.Forms.ComboBox();
            this.QueryTypeLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.ShiftGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // ShiftGridView
            // 
            this.ShiftGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ShiftGridView.Location = new System.Drawing.Point(12, 125);
            this.ShiftGridView.Name = "ShiftGridView";
            this.ShiftGridView.Size = new System.Drawing.Size(854, 317);
            this.ShiftGridView.TabIndex = 0;
            // 
            // CmdButton
            // 
            this.CmdButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.CmdButton.Location = new System.Drawing.Point(12, 73);
            this.CmdButton.Name = "CmdButton";
            this.CmdButton.Size = new System.Drawing.Size(854, 46);
            this.CmdButton.TabIndex = 1;
            this.CmdButton.Text = "Выполнить операцию!";
            this.CmdButton.UseVisualStyleBackColor = true;
            this.CmdButton.Click += new System.EventHandler(this.CmdButton_Click);
            // 
            // QueryTypeComboBox
            // 
            this.QueryTypeComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.QueryTypeComboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.QueryTypeComboBox.FormattingEnabled = true;
            this.QueryTypeComboBox.Items.AddRange(new object[] {
            "Сохранить изменения",
            "Удалить строку"});
            this.QueryTypeComboBox.Location = new System.Drawing.Point(219, 16);
            this.QueryTypeComboBox.Name = "QueryTypeComboBox";
            this.QueryTypeComboBox.Size = new System.Drawing.Size(647, 41);
            this.QueryTypeComboBox.TabIndex = 2;
            this.QueryTypeComboBox.TabStop = false;
            this.QueryTypeComboBox.SelectedIndexChanged += new System.EventHandler(this.QueryTypeComboBox_SelectedIndexChanged);
            // 
            // QueryTypeLabel
            // 
            this.QueryTypeLabel.AutoSize = true;
            this.QueryTypeLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.QueryTypeLabel.Location = new System.Drawing.Point(12, 20);
            this.QueryTypeLabel.Name = "QueryTypeLabel";
            this.QueryTypeLabel.Size = new System.Drawing.Size(201, 31);
            this.QueryTypeLabel.TabIndex = 3;
            this.QueryTypeLabel.Text = "Тип операции";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(878, 454);
            this.Controls.Add(this.QueryTypeLabel);
            this.Controls.Add(this.QueryTypeComboBox);
            this.Controls.Add(this.CmdButton);
            this.Controls.Add(this.ShiftGridView);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.ShiftGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView ShiftGridView;
        private System.Windows.Forms.Button CmdButton;
        private System.Windows.Forms.ComboBox QueryTypeComboBox;
        private System.Windows.Forms.Label QueryTypeLabel;
    }
}

