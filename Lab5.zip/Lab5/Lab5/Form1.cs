﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab5
{
    public partial class Form1 : Form
    {
        //private BindingList<Shift> _shifts;
        string strSQL;
        string strConn;
        DataSet ds;
        OleDbDataAdapter da;
        OleDbConnection conn;
        string QueryTypeName;
        public Form1()
        {
            InitializeComponent();
            //_shifts = new BindingList<Shift>();
            strSQL = "SELECT * FROM shifts";
            strConn = System.Configuration.ConfigurationManager.ConnectionStrings["СashboxConnectionString"].ConnectionString;
            ds = new DataSet();
            using(conn = new OleDbConnection(strConn))
{
                da = new OleDbDataAdapter(strSQL, conn);
                da.Fill(ds, "shifts");
                ShiftGridView.AutoGenerateColumns = true;
                ShiftGridView.DataSource = ds;
                ShiftGridView.DataMember = "shifts";
            }
        }

        private void QueryTypeComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void CmdButton_Click(object sender, EventArgs e)
        {
            QueryTypeName = QueryTypeComboBox.Text;
            switch (QueryTypeName)
            {
                case "Сохранить изменения":

                    break;
                case "Удалить строку":

                    break;
                default:
                    MessageBox.Show("Тип операции не выбран!");
                    break;
            }
        }
    }
}
