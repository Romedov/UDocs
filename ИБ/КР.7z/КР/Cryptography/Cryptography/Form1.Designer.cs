﻿namespace Cryptography
{
    partial class Form1
    {
        /// <summary>
        /// Требуется переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Обязательный метод для поддержки конструктора - не изменяйте
        /// содержимое данного метода при помощи редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.PathTB = new System.Windows.Forms.TextBox();
            this.HashOutputRTB = new System.Windows.Forms.RichTextBox();
            this.GetFileDataBtn = new System.Windows.Forms.Button();
            this.FileDataRTB = new System.Windows.Forms.RichTextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.SaveBtn = new System.Windows.Forms.Button();
            this.ComputeHashBtn = new System.Windows.Forms.Button();
            this.CopyToBufferBtn = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.AddSymbolTB = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.AddPositionNUD = new System.Windows.Forms.NumericUpDown();
            this.ComputeAvalancheBtn = new System.Windows.Forms.Button();
            this.AvalancheTB = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.AddPositionNUD)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(9, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(106, 18);
            this.label1.TabIndex = 0;
            this.label1.Text = "Путь к файлу:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(9, 338);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 18);
            this.label2.TabIndex = 1;
            this.label2.Text = "Хэш:";
            // 
            // PathTB
            // 
            this.PathTB.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.PathTB.Location = new System.Drawing.Point(12, 30);
            this.PathTB.Name = "PathTB";
            this.PathTB.Size = new System.Drawing.Size(359, 24);
            this.PathTB.TabIndex = 2;
            // 
            // HashOutputRTB
            // 
            this.HashOutputRTB.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.HashOutputRTB.Location = new System.Drawing.Point(12, 359);
            this.HashOutputRTB.Name = "HashOutputRTB";
            this.HashOutputRTB.ReadOnly = true;
            this.HashOutputRTB.Size = new System.Drawing.Size(359, 130);
            this.HashOutputRTB.TabIndex = 3;
            this.HashOutputRTB.Text = "";
            // 
            // GetFileDataBtn
            // 
            this.GetFileDataBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.GetFileDataBtn.Location = new System.Drawing.Point(192, 69);
            this.GetFileDataBtn.Name = "GetFileDataBtn";
            this.GetFileDataBtn.Size = new System.Drawing.Size(179, 29);
            this.GetFileDataBtn.TabIndex = 4;
            this.GetFileDataBtn.Text = "Считать содержимое";
            this.GetFileDataBtn.UseVisualStyleBackColor = true;
            this.GetFileDataBtn.Click += new System.EventHandler(this.GetFileDataBtn_Click);
            // 
            // FileDataRTB
            // 
            this.FileDataRTB.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FileDataRTB.Location = new System.Drawing.Point(12, 122);
            this.FileDataRTB.Name = "FileDataRTB";
            this.FileDataRTB.Size = new System.Drawing.Size(359, 130);
            this.FileDataRTB.TabIndex = 5;
            this.FileDataRTB.Text = "";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(9, 101);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(154, 18);
            this.label3.TabIndex = 6;
            this.label3.Text = "Содержимое файла:";
            // 
            // SaveBtn
            // 
            this.SaveBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.SaveBtn.Location = new System.Drawing.Point(192, 306);
            this.SaveBtn.Name = "SaveBtn";
            this.SaveBtn.Size = new System.Drawing.Size(179, 29);
            this.SaveBtn.TabIndex = 7;
            this.SaveBtn.Text = "Сохранить изменения";
            this.SaveBtn.UseVisualStyleBackColor = true;
            this.SaveBtn.Click += new System.EventHandler(this.SaveBtn_Click);
            // 
            // ComputeHashBtn
            // 
            this.ComputeHashBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ComputeHashBtn.Location = new System.Drawing.Point(12, 306);
            this.ComputeHashBtn.Name = "ComputeHashBtn";
            this.ComputeHashBtn.Size = new System.Drawing.Size(174, 29);
            this.ComputeHashBtn.TabIndex = 8;
            this.ComputeHashBtn.Text = "Получить хэш";
            this.ComputeHashBtn.UseVisualStyleBackColor = true;
            this.ComputeHashBtn.Click += new System.EventHandler(this.ComputeHashBtn_Click);
            // 
            // CopyToBufferBtn
            // 
            this.CopyToBufferBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.CopyToBufferBtn.Location = new System.Drawing.Point(140, 495);
            this.CopyToBufferBtn.Name = "CopyToBufferBtn";
            this.CopyToBufferBtn.Size = new System.Drawing.Size(231, 29);
            this.CopyToBufferBtn.TabIndex = 9;
            this.CopyToBufferBtn.Text = "Скопировать в буфер обмена";
            this.CopyToBufferBtn.UseVisualStyleBackColor = true;
            this.CopyToBufferBtn.Click += new System.EventHandler(this.CopyToBufferBtn_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(12, 255);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(159, 18);
            this.label4.TabIndex = 10;
            this.label4.Text = "Добавочный символ:";
            // 
            // AddSymbolTB
            // 
            this.AddSymbolTB.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.AddSymbolTB.Location = new System.Drawing.Point(12, 276);
            this.AddSymbolTB.Name = "AddSymbolTB";
            this.AddSymbolTB.Size = new System.Drawing.Size(174, 24);
            this.AddSymbolTB.TabIndex = 11;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(189, 255);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(131, 18);
            this.label5.TabIndex = 12;
            this.label5.Text = "Позиция вставки:";
            // 
            // AddPositionNUD
            // 
            this.AddPositionNUD.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.AddPositionNUD.Location = new System.Drawing.Point(192, 276);
            this.AddPositionNUD.Name = "AddPositionNUD";
            this.AddPositionNUD.Size = new System.Drawing.Size(179, 24);
            this.AddPositionNUD.TabIndex = 14;
            // 
            // ComputeAvalancheBtn
            // 
            this.ComputeAvalancheBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ComputeAvalancheBtn.Location = new System.Drawing.Point(130, 578);
            this.ComputeAvalancheBtn.Name = "ComputeAvalancheBtn";
            this.ComputeAvalancheBtn.Size = new System.Drawing.Size(241, 29);
            this.ComputeAvalancheBtn.TabIndex = 15;
            this.ComputeAvalancheBtn.Text = "Подсчитать лавинный эффект";
            this.ComputeAvalancheBtn.UseVisualStyleBackColor = true;
            this.ComputeAvalancheBtn.MouseClick += new System.Windows.Forms.MouseEventHandler(this.ComputeAvalancheBtn_MouseClick);
            // 
            // AvalancheTB
            // 
            this.AvalancheTB.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.AvalancheTB.Location = new System.Drawing.Point(12, 548);
            this.AvalancheTB.Name = "AvalancheTB";
            this.AvalancheTB.ReadOnly = true;
            this.AvalancheTB.Size = new System.Drawing.Size(359, 24);
            this.AvalancheTB.TabIndex = 16;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.Location = new System.Drawing.Point(12, 527);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(143, 18);
            this.label6.TabIndex = 17;
            this.label6.Text = "Лавинный эффект:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(383, 616);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.AvalancheTB);
            this.Controls.Add(this.ComputeAvalancheBtn);
            this.Controls.Add(this.AddPositionNUD);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.AddSymbolTB);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.CopyToBufferBtn);
            this.Controls.Add(this.ComputeHashBtn);
            this.Controls.Add(this.SaveBtn);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.FileDataRTB);
            this.Controls.Add(this.GetFileDataBtn);
            this.Controls.Add(this.HashOutputRTB);
            this.Controls.Add(this.PathTB);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.AddPositionNUD)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox PathTB;
        private System.Windows.Forms.RichTextBox HashOutputRTB;
        private System.Windows.Forms.Button GetFileDataBtn;
        private System.Windows.Forms.RichTextBox FileDataRTB;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button SaveBtn;
        private System.Windows.Forms.Button ComputeHashBtn;
        private System.Windows.Forms.Button CopyToBufferBtn;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox AddSymbolTB;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.NumericUpDown AddPositionNUD;
        private System.Windows.Forms.Button ComputeAvalancheBtn;
        private System.Windows.Forms.TextBox AvalancheTB;
        private System.Windows.Forms.Label label6;
    }
}

