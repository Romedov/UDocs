﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Security.Cryptography;

namespace Cryptography
{
    public static class SHA512MHasher
    {
        public static string GetHash(string input, Encoding encoding)
        {
            byte[] data = encoding.GetBytes(input);
            var result = new SHA512Managed().ComputeHash(data);
            return BitConverter.ToString(result).Replace("-", "").ToLower();
        }
    }
}
