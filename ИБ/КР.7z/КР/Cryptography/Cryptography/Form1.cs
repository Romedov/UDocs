﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cryptography
{
    public partial class Form1 : Form
    {
        public string FileData { get; private set; }
        public string FileDataModified { get; private set; }
        public string Path { get; private set; }
        public string Hash { get; private set; }
        public string AdditionalString { get; private set; }
        public int Position { get; private set; }
        public byte[] HashBytes { get; private set; }
        public byte[] FileDataBytes { get; private set; }
        public int AvalancheEffect { get; private set; }

        public Form1()
        {
            InitializeComponent();
        }

        private void GetFileDataBtn_Click(object sender, EventArgs e)
        {
            Path = @PathTB.Text; ;
            try
            {
                using (StreamReader reader = new StreamReader(Path))
                {
                    FileData = reader.ReadToEnd();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            FileDataRTB.Text = FileData;
        }

        private async void SaveBtn_Click(object sender, EventArgs e)
        {
            try
            {
                using (StreamWriter writer = new StreamWriter(Path, false))
                {
                    foreach (string str in FileDataRTB.Lines)
                    {
                        await writer.WriteLineAsync(str);
                    }
                }
                FileData = FileDataRTB.Text;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private async void ComputeHashBtn_Click(object sender, EventArgs e)
        {
            Position = Convert.ToInt32(AddPositionNUD.Value);
            AdditionalString = AddSymbolTB.Text;
            if (Position >=0 && AdditionalString != "") //если индекс вставки больше нуля и
            {                                           //вставочная строка не пуста
                FileDataModified = FileData.Insert(Position, AdditionalString);
            }
            Hash = SHA512MHasher.GetHash(FileDataModified, Encoding.UTF8);
            HashOutputRTB.Text = Hash;
            try
            {
                using (StreamWriter writer = new StreamWriter(Path, true))
                {
                    await writer.WriteLineAsync();
                    await writer.WriteLineAsync(Hash);
                }
                FileData = FileDataRTB.Text;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void CopyToBufferBtn_Click(object sender, EventArgs e)
        {
            Clipboard.SetText(Hash);
        }
        public static string exclusiveOR(byte[] key, byte[] PAN)
        {
            byte[] result = new byte[key.Length];
            for (int i = 0; i < Math.Min(key.Length, PAN.Length); i++)
            {
                result[i] = (byte)(key[i] ^ PAN[i]);
            }
            string hex = BitConverter.ToString(result).Replace("-", "");
            return hex;

        }
        private void ComputeAvalancheBtn_MouseClick(object sender, MouseEventArgs e)
        {
            HashBytes = Encoding.UTF8.GetBytes(Hash);
            FileDataBytes = Encoding.UTF8.GetBytes(FileDataModified);
            string XORedMessage = exclusiveOR(HashBytes, FileDataBytes);
            int count = 0;
            string binaryString = string.Join("", XORedMessage.Select(b => Convert.ToString(b, 2)));
            foreach(char bit in binaryString)
            {
                if (bit == '1')
                {
                    count++;
                }
            }
            AvalancheEffect = count;
            AvalancheTB.Text = AvalancheEffect.ToString();
        }
    }
}
