﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Odbc;

namespace Lab2
{
    public partial class Form1 : Form
    {
        OdbcConnection conn = new OdbcConnection();
        OdbcCommand cmd;
        Random rnd = new Random();
        int Result = 0;
        public Form1()
        {
            InitializeComponent();
            this.conn.ConnectionString = @"Driver={Microsoft Access Driver (*.mdb, *.accdb)};" + //драйвер
                "DBQ=E:\\4 курс\\Прикладное программирование\\Cashbox.accdb;" + //путь к файлу бд
                "Uid=root;" + //пользователь
                "Pwd=1243;"; //пароль
        }
        public void ExecuteQuery(object sender, EventArgs e)
        {
            switch (((Button)sender).Name)
            {
                case "InsertBtn":
                    try
                    {
                        this.conn.Open();
                        cmd = new OdbcCommand("INSERT INTO shifts (startDate, endDate, cash, sellings, returns, put, withdrawn) VALUES (?, ?, ?, ?, ?, ?, ?)", conn);
                        cmd.Parameters.AddWithValue("", DateTime.Now.ToString("d"));
                        cmd.Parameters.AddWithValue("", DateTime.Now.ToString("d"));
                        cmd.Parameters.AddWithValue("", rnd.Next(10000) + rnd.NextDouble());
                        cmd.Parameters.AddWithValue("", rnd.Next(10000) + rnd.NextDouble());
                        cmd.Parameters.AddWithValue("", rnd.Next(10000) + rnd.NextDouble());
                        cmd.Parameters.AddWithValue("", rnd.Next(10000) + rnd.NextDouble());
                        cmd.Parameters.AddWithValue("", rnd.Next(10000) + rnd.NextDouble());
                        Result = cmd.ExecuteNonQuery();
                        if (Result > 0)
                            textBox1.Text = "Insert query is complete!";
                        else
                            textBox1.Text = "Insert query isn't complete!";
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"ODBC-соединение не установлено!\nОшибка: {ex.Message}");
                    }
                    finally
                    {
                        cmd.Parameters.Clear();
                        this.conn.Close();
                    }
                break;
                case "UpdateBtn":
                    try
                    {
                        this.conn.Open();
                        cmd = new OdbcCommand("SELECT MAX(id) AS max FROM shifts", conn);
                        Result = int.Parse(cmd.ExecuteScalar().ToString());
                        if (Result <= 0)
                            textBox1.Text = "Select query failed!";
                        else
                        {
                            cmd = new OdbcCommand("UPDATE shifts SET startDate=?, endDate=?, cash=?, sellings=?, returns=?, put=?, withdrawn=? WHERE id=?", conn);
                            cmd.Parameters.AddWithValue("", DateTime.Now.ToString("d"));
                            cmd.Parameters.AddWithValue("", DateTime.Now.ToString("d"));
                            cmd.Parameters.AddWithValue("", rnd.Next(10000) + rnd.NextDouble());
                            cmd.Parameters.AddWithValue("", rnd.Next(10000) + rnd.NextDouble());
                            cmd.Parameters.AddWithValue("", rnd.Next(10000) + rnd.NextDouble());
                            cmd.Parameters.AddWithValue("", rnd.Next(10000) + rnd.NextDouble());
                            cmd.Parameters.AddWithValue("", rnd.Next(10000) + rnd.NextDouble());
                            cmd.Parameters.AddWithValue("", Result);
                            Result = cmd.ExecuteNonQuery();
                            if (Result > 0)
                                textBox1.Text = "Update query is complete!";
                            else
                                textBox1.Text = "Update query isn't complete!";
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"ODBC-соединение не установлено!\nОшибка: {ex.Message}");
                    }
                    finally
                    {
                        cmd.Parameters.Clear();
                        this.conn.Close();
                    }
                break;
                case "DeleteBtn":
                    try
                    {
                        this.conn.Open();
                        cmd = new OdbcCommand("SELECT MAX(id) AS max FROM shifts", conn);
                        Result = int.Parse(cmd.ExecuteScalar().ToString());
                        if (Result <= 0)
                            MessageBox.Show("Select query failed!");
                        else
                        {
                            cmd = new OdbcCommand("DELETE FROM shifts WHERE id=?", conn);
                            cmd.Parameters.AddWithValue("", Result);
                            Result = cmd.ExecuteNonQuery();
                            if (Result > 0)
                                textBox1.Text = "Delete query is complete!";
                            else
                                textBox1.Text = "Delete query isn't complete!";
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"ODBC-соединение не установлено!\nОшибка: {ex.Message}");
                    }
                    finally
                    {
                        cmd.Parameters.Clear();
                        this.conn.Close();
                    }
                break;
            }
        }
    }
}
