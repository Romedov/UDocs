﻿using System;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Configuration;

namespace Lab6Kham
{
    public partial class Form1 : Form
    {
        string connStr;
        string AdapterString;
        OleDbDataAdapter adapter;
        SKDataSet tds;
        public Form1()
        {
            InitializeComponent();
            AdapterString = "SELECT * FROM Salon";
            connStr = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
            tds = new SKDataSet();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                using (OleDbConnection conn = new OleDbConnection(connStr))
                {
                    adapter = new OleDbDataAdapter(AdapterString, conn);
                    adapter.Fill(tds.Salon);
                    dataGridView1.DataSource = tds.Salon;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
