﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1
{
    delegate void DBHandler(object sender, DBEventArgs e);
    class DBEventArgs
    {
        //public string EventMessage { get; set; }
        public bool IsSuccessful { get; set; }
        public DBEventArgs(/*string message,*/ bool isSuccessful)
        {
            //EventMessage = message;
            IsSuccessful = isSuccessful;
        }
    }
    class DBCustomClass
    {
        public event DBHandler Connecting;
        public void Connect()
        {
            Connecting?.Invoke(this, new DBEventArgs(true));
        }
    }
}
