﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Odbc;

namespace Lab1
{
    public partial class Form1 : Form
    {
        OdbcConnection conn1 = new OdbcConnection();
        OdbcConnection conn2 = new OdbcConnection();
        public Form1()
        {
            InitializeComponent();
            this.conn1.ConnectionString = @"Driver={Microsoft Access Driver (*.mdb, *.accdb)};" + //драйвер
                "DBQ=E:\\4 курс\\Прикладное программирование\\Cashbox.accdb;"; //путь к файлу бд
            this.conn2.ConnectionString = "UID=root;" + //пользователь
                "FILEDSN=E:\\4 курс\\Прикладное программирование\\MyDSN.dsn;" + //путь к файлу DSN
                "PWD=1243"; //пароль
        }

        public void Connect(object sender, EventArgs e)
        {
            switch (((Button)sender).Name)
            {
                case "button1":
                    try
                    {
                        this.conn1.Open();
                        MessageBox.Show("Динамическое ODBC-соединение установлено!");
                    }
                    catch(Exception ex)
                    {
                        MessageBox.Show($"Динамическое ODBC-соединение не установлено!\nОшибка: {ex.Message}");
                    }
                    finally
                    {
                        this.conn1.Close();
                    }
                break;
                case "button2":
                    try
                    {
                        this.conn2.Open();
                        MessageBox.Show("DSN ODBC-соединение установлено!");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"DSN ODBC-соединение не установлено!\nОшибка: {ex.Message}");
                    }
                    finally
                    {
                        this.conn2.Close();
                    }
                break;
            }
        }
    }
}
