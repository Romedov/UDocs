﻿namespace Lab3
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.InsButton = new System.Windows.Forms.Button();
            this.UpdButton = new System.Windows.Forms.Button();
            this.DelButton = new System.Windows.Forms.Button();
            this.ShiftGridView = new System.Windows.Forms.DataGridView();
            this.cashboxDataSet = new Lab3.CashboxDataSet();
            this.shiftsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.shiftsTableAdapter = new Lab3.CashboxDataSetTableAdapters.shiftsTableAdapter();
            this.ShiftIdListBox = new System.Windows.Forms.ListBox();
            this.startDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.endDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cashDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sellingsDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.returnsDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.putDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.withdrawnDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ShiftComboBox = new System.Windows.Forms.ComboBox();
            this.UpdBtn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.ShiftGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cashboxDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.shiftsBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // InsButton
            // 
            this.InsButton.Location = new System.Drawing.Point(414, 19);
            this.InsButton.Name = "InsButton";
            this.InsButton.Size = new System.Drawing.Size(339, 95);
            this.InsButton.TabIndex = 0;
            this.InsButton.Text = "INSERT";
            this.InsButton.UseVisualStyleBackColor = true;
            this.InsButton.Click += new System.EventHandler(this.InsButton_Click);
            // 
            // UpdButton
            // 
            this.UpdButton.Location = new System.Drawing.Point(212, 48);
            this.UpdButton.Name = "UpdButton";
            this.UpdButton.Size = new System.Drawing.Size(181, 173);
            this.UpdButton.TabIndex = 1;
            this.UpdButton.Text = "UPDATE";
            this.UpdButton.UseVisualStyleBackColor = true;
            this.UpdButton.Click += new System.EventHandler(this.UpdButton_Click);
            // 
            // DelButton
            // 
            this.DelButton.Location = new System.Drawing.Point(12, 19);
            this.DelButton.Name = "DelButton";
            this.DelButton.Size = new System.Drawing.Size(181, 23);
            this.DelButton.TabIndex = 2;
            this.DelButton.Text = "DELETE";
            this.DelButton.UseVisualStyleBackColor = true;
            this.DelButton.Click += new System.EventHandler(this.DelButton_Click);
            // 
            // ShiftGridView
            // 
            this.ShiftGridView.AutoGenerateColumns = false;
            this.ShiftGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ShiftGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.startDateDataGridViewTextBoxColumn,
            this.endDateDataGridViewTextBoxColumn,
            this.cashDataGridViewTextBoxColumn,
            this.sellingsDataGridViewTextBoxColumn,
            this.returnsDataGridViewTextBoxColumn,
            this.putDataGridViewTextBoxColumn,
            this.withdrawnDataGridViewTextBoxColumn});
            this.ShiftGridView.DataSource = this.shiftsBindingSource;
            this.ShiftGridView.Location = new System.Drawing.Point(12, 227);
            this.ShiftGridView.Name = "ShiftGridView";
            this.ShiftGridView.Size = new System.Drawing.Size(744, 150);
            this.ShiftGridView.TabIndex = 3;
            // 
            // cashboxDataSet
            // 
            this.cashboxDataSet.DataSetName = "CashboxDataSet";
            this.cashboxDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // shiftsBindingSource
            // 
            this.shiftsBindingSource.DataMember = "shifts";
            this.shiftsBindingSource.DataSource = this.cashboxDataSet;
            // 
            // shiftsTableAdapter
            // 
            this.shiftsTableAdapter.ClearBeforeFill = true;
            // 
            // ShiftIdListBox
            // 
            this.ShiftIdListBox.DataSource = this.shiftsBindingSource;
            this.ShiftIdListBox.DisplayMember = "id";
            this.ShiftIdListBox.FormattingEnabled = true;
            this.ShiftIdListBox.Location = new System.Drawing.Point(12, 48);
            this.ShiftIdListBox.Name = "ShiftIdListBox";
            this.ShiftIdListBox.Size = new System.Drawing.Size(181, 173);
            this.ShiftIdListBox.TabIndex = 4;
            this.ShiftIdListBox.ValueMember = "id";
            // 
            // startDateDataGridViewTextBoxColumn
            // 
            this.startDateDataGridViewTextBoxColumn.DataPropertyName = "startDate";
            this.startDateDataGridViewTextBoxColumn.HeaderText = "startDate";
            this.startDateDataGridViewTextBoxColumn.Name = "startDateDataGridViewTextBoxColumn";
            // 
            // endDateDataGridViewTextBoxColumn
            // 
            this.endDateDataGridViewTextBoxColumn.DataPropertyName = "endDate";
            this.endDateDataGridViewTextBoxColumn.HeaderText = "endDate";
            this.endDateDataGridViewTextBoxColumn.Name = "endDateDataGridViewTextBoxColumn";
            // 
            // cashDataGridViewTextBoxColumn
            // 
            this.cashDataGridViewTextBoxColumn.DataPropertyName = "cash";
            this.cashDataGridViewTextBoxColumn.HeaderText = "cash";
            this.cashDataGridViewTextBoxColumn.Name = "cashDataGridViewTextBoxColumn";
            // 
            // sellingsDataGridViewTextBoxColumn
            // 
            this.sellingsDataGridViewTextBoxColumn.DataPropertyName = "sellings";
            this.sellingsDataGridViewTextBoxColumn.HeaderText = "sellings";
            this.sellingsDataGridViewTextBoxColumn.Name = "sellingsDataGridViewTextBoxColumn";
            // 
            // returnsDataGridViewTextBoxColumn
            // 
            this.returnsDataGridViewTextBoxColumn.DataPropertyName = "returns";
            this.returnsDataGridViewTextBoxColumn.HeaderText = "returns";
            this.returnsDataGridViewTextBoxColumn.Name = "returnsDataGridViewTextBoxColumn";
            // 
            // putDataGridViewTextBoxColumn
            // 
            this.putDataGridViewTextBoxColumn.DataPropertyName = "put";
            this.putDataGridViewTextBoxColumn.HeaderText = "put";
            this.putDataGridViewTextBoxColumn.Name = "putDataGridViewTextBoxColumn";
            // 
            // withdrawnDataGridViewTextBoxColumn
            // 
            this.withdrawnDataGridViewTextBoxColumn.DataPropertyName = "withdrawn";
            this.withdrawnDataGridViewTextBoxColumn.HeaderText = "withdrawn";
            this.withdrawnDataGridViewTextBoxColumn.Name = "withdrawnDataGridViewTextBoxColumn";
            // 
            // ShiftComboBox
            // 
            this.ShiftComboBox.DataSource = this.shiftsBindingSource;
            this.ShiftComboBox.DisplayMember = "id";
            this.ShiftComboBox.FormattingEnabled = true;
            this.ShiftComboBox.Location = new System.Drawing.Point(211, 21);
            this.ShiftComboBox.Name = "ShiftComboBox";
            this.ShiftComboBox.Size = new System.Drawing.Size(182, 21);
            this.ShiftComboBox.TabIndex = 5;
            this.ShiftComboBox.ValueMember = "id";
            // 
            // UpdBtn
            // 
            this.UpdBtn.Location = new System.Drawing.Point(414, 130);
            this.UpdBtn.Name = "UpdBtn";
            this.UpdBtn.Size = new System.Drawing.Size(342, 91);
            this.UpdBtn.TabIndex = 6;
            this.UpdBtn.Text = "UPD";
            this.UpdBtn.UseVisualStyleBackColor = true;
            this.UpdBtn.Click += new System.EventHandler(this.UpdBtn_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(765, 385);
            this.Controls.Add(this.UpdBtn);
            this.Controls.Add(this.ShiftComboBox);
            this.Controls.Add(this.ShiftIdListBox);
            this.Controls.Add(this.ShiftGridView);
            this.Controls.Add(this.DelButton);
            this.Controls.Add(this.UpdButton);
            this.Controls.Add(this.InsButton);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.ShiftGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cashboxDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.shiftsBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button InsButton;
        private System.Windows.Forms.Button UpdButton;
        private System.Windows.Forms.Button DelButton;
        private System.Windows.Forms.DataGridView ShiftGridView;
        private CashboxDataSet cashboxDataSet;
        private System.Windows.Forms.BindingSource shiftsBindingSource;
        private CashboxDataSetTableAdapters.shiftsTableAdapter shiftsTableAdapter;
        private System.Windows.Forms.ListBox ShiftIdListBox;
        private System.Windows.Forms.DataGridViewTextBoxColumn startDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn endDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cashDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sellingsDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn returnsDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn putDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn withdrawnDataGridViewTextBoxColumn;
        private System.Windows.Forms.ComboBox ShiftComboBox;
        private System.Windows.Forms.Button UpdBtn;
    }
}

