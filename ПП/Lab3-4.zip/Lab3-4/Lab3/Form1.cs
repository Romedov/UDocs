﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Lab3
{
    public partial class Form1 : Form
    {
        OleDbConnection conn = new OleDbConnection();
        OleDbCommand cmd;
        Random rnd = new Random();
        int Result = 0;
        int selectedItem;
        public Form1()
        {
            InitializeComponent();
            conn.ConnectionString = @"Provider=Microsoft.ACE.OLEDB.12.0; Data Source = E:\\4 курс\\Прикладное программирование\\Cashbox.accdb";
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "cashboxDataSet.shifts". При необходимости она может быть перемещена или удалена.
            this.shiftsTableAdapter.Fill(this.cashboxDataSet.shifts);

        }

        private void InsButton_Click(object sender, EventArgs e)
        {
            try
            {
                var v = ShiftGridView.DataSource;
                this.conn.Open();
                cmd = new OleDbCommand("INSERT INTO shifts (startDate, endDate, cash, sellings, returns, put, withdrawn) VALUES (?, ?, ?, ?, ?, ?, ?)", conn);
                cmd.Parameters.AddWithValue("", DateTime.Now.ToString("d"));
                cmd.Parameters.AddWithValue("", DateTime.Now.ToString("d"));
                cmd.Parameters.AddWithValue("", rnd.Next(10000) + rnd.NextDouble());
                cmd.Parameters.AddWithValue("", rnd.Next(10000) + rnd.NextDouble());
                cmd.Parameters.AddWithValue("", rnd.Next(10000) + rnd.NextDouble());
                cmd.Parameters.AddWithValue("", rnd.Next(10000) + rnd.NextDouble());
                cmd.Parameters.AddWithValue("", rnd.Next(10000) + rnd.NextDouble());
                Result = cmd.ExecuteNonQuery();
                if (Result > 0)
                {
                    nUpdate();
                }
                else
                    MessageBox.Show("Insert query isn't complete!");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"OleDb-соединение не установлено!\nОшибка: {ex.Message}");
            }
            finally
            {
                cmd.Parameters.Clear();
                this.conn.Close();
            }

        }

        private void UpdButton_Click(object sender, EventArgs e)
        {
            int id = int.Parse(ShiftComboBox.Text);
            try
            {
                this.conn.Open();
                cmd = new OleDbCommand("UPDATE shifts SET startDate=?, endDate=?, cash=?, sellings=?, returns=?, put=?, withdrawn=? WHERE id=?", conn);
                cmd.Parameters.AddWithValue("", DateTime.Now.ToString("d"));
                cmd.Parameters.AddWithValue("", DateTime.Now.ToString("d"));
                cmd.Parameters.AddWithValue("", rnd.Next(10000) + rnd.NextDouble());
                cmd.Parameters.AddWithValue("", rnd.Next(10000) + rnd.NextDouble());
                cmd.Parameters.AddWithValue("", rnd.Next(10000) + rnd.NextDouble());
                cmd.Parameters.AddWithValue("", rnd.Next(10000) + rnd.NextDouble());
                cmd.Parameters.AddWithValue("", rnd.Next(10000) + rnd.NextDouble());
                cmd.Parameters.AddWithValue("", id);
                Result = cmd.ExecuteNonQuery();
                if (Result <= 0)
                    MessageBox.Show("Delete query isn't complete!");
                else
                {
                    nUpdate();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"OleDb-соединение не установлено!\nОшибка: {ex.Message}");
            }
            finally
            {
                cmd.Parameters.Clear();
                this.conn.Close();
            }
        }

        private void DelButton_Click(object sender, EventArgs e)
        {
            selectedItem = int.Parse(ShiftIdListBox.GetItemText(ShiftIdListBox.SelectedItem));
            try
            {
                this.conn.Open();
                cmd = new OleDbCommand("DELETE FROM shifts WHERE id=?", conn);
                cmd.Parameters.AddWithValue("", selectedItem);
                Result = cmd.ExecuteNonQuery();
                if (Result <= 0)
                    MessageBox.Show("Delete query isn't complete!");
                else
                {
                    nUpdate();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"OleDb-соединение не установлено!\nОшибка: {ex.Message}");
            }
            finally
            {
                cmd.Parameters.Clear();
                this.conn.Close();
            }
        }
        private void nUpdate()
        {
            this.shiftsTableAdapter.ClearBeforeFill = true;
            var CashboxDataSet = cashboxDataSet;
            if (CashboxDataSet != null)
            {
                this.shiftsTableAdapter.Fill(CashboxDataSet.shifts);
                ShiftIdListBox.Refresh();
                ShiftGridView.Refresh();
            }
            else
            {
                MessageBox.Show("Nope :т");
            }
        }

        private void UpdBtn_Click(object sender, EventArgs e)
        {
            nUpdate();
        }
    }
}
